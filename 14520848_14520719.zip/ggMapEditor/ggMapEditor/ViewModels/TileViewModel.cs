﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace ggMapEditor.ViewModels
{
    class TileViewModel : Base.BaseViewModel
    {
        private Models.Tile tile;
        //public int Id
        //{
        //    get { return tile.id; }
        //    private set { }
        //}
        //public ulong position
        //{
        //    get { return tile.position; }
        //    set
        //    {
        //        tile.position = value;
        //        RaisePropertyChanged("Position");
        //    }
        //}
        //public ImageSource Image
        //{
        //    get { return tile.image; }
        //    set
        //    {
        //        tile.image = value;
        //        RaisePropertyChanged("ImageSource");
        //    }
        //}
        //public int size
        //{
        //    get { return tile.size; }
        //    set
        //    {
        //        tile.size = value;
        //        RaisePropertyChanged("TileSize");
        //    }
        //}
    }
}
