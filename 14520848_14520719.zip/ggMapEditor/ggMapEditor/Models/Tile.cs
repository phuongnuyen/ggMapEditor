﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ggMapEditor.Models
{
    public class Tile
    {
        public long id { get; set; }
        public long imgId { get; set; }
        public Int32Rect rectPos { get; set; }

        public Tile()
        {
            //rectPos = Int32Rect.Empty;
        }
    }
}