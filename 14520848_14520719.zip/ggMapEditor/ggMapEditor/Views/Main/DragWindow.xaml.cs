﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace ggMapEditor.Views.Main
{
    /// <summary>
    /// Interaction logic for DragWindow.xaml
    /// </summary>
    public partial class DragWindow : Window
    {
        public DragWindow()
        {
            InitializeComponent();
        }
    }
}
