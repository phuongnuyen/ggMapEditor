﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using ggMapEditor.QuadTree;
using Newtonsoft.Json;

namespace ggMapEditor.Json
{
    public static class ConvertJson
    {
        public static string SaveFile(Models.Combine combine)
        {
            // Dua vao QuadTree de lay id, rect
            Models.TileMap tileMap = combine.tileMap;
            ObservableCollection<QTObject<Models.Tile>> listQTObj = new ObservableCollection<QTObject<Models.Tile>>();
            foreach (var tile in tileMap.listTile)
            {
                QTObject<Models.Tile> obj = new QTObject<Models.Tile>(tile.rectPos, tile);
                listQTObj.Add(obj);
            }
            Int32Rect rect = new Int32Rect(0, 0, tileMap.width, tileMap.height);
            QuadTree<Models.Tile> quadTree = new QuadTree.QuadTree<Models.Tile>(rect, listQTObj);
            quadTree.CreateQuadTree();

            listQTObj.Clear();
            listQTObj = quadTree.RetrieveObjects();

            // Tra ve listTile cho tileMap
            tileMap.listTile.Clear();
            foreach(var qtObj in listQTObj)
            {
                Models.Tile tile = new Models.Tile();
                tile = qtObj.obj;
                tile.id = qtObj.id;
                tileMap.listTile.Add(tile);
            }

            string json = JsonConvert.SerializeObject(tileMap);
            string filePath = combine.folderPath + "\\" + combine.folderName + ".json";

            if (!Directory.Exists(filePath))
                Directory.CreateDirectory(combine.folderPath);
            System.IO.File.WriteAllText(filePath, json);
            return json;
        }
    }
}
